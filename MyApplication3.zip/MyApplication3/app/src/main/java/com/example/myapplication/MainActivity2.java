package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        String fio;
        String result;

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        TextView txt = findViewById(R.id.textView);
        RadioButton rbtn = findViewById(R.id.radioButton);
        RadioButton rbtn2 = findViewById(R.id.radioButton2);
        Button btn = findViewById(R.id.button2);

        Bundle extras = getIntent().getExtras();

        if (extras != null){
            fio = extras.getString("name");
        }else{
            fio = "Никого не записали";
        }

        txt.setText(fio);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent itn1 = new Intent(MainActivity2.this, MainActivity.class);
                if (rbtn.isChecked()){
            }
        });
    }
}